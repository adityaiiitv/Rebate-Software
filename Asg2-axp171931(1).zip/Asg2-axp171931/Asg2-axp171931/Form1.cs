﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Text.RegularExpressions;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        //public ListBox listBox1 = new ListBox();
        //public ListView lv = new ListView();
        public string ts = null, te = null;
        public int tflag = 0,tflag1=0,restoreflag=0;
        public string fn1 = null, ln1 = null, mi1 = null, ad3 = null, ad4 = null, c1 = null, s1 = null, zip1 = null, ph1 = null, e1=null, proof1=null, date1=null;
        public Form1()
        {

            //update();
            InitializeComponent();
        }
        
        public void update()
        {
            listView1.Items.Clear();
            listView1.Size = new System.Drawing.Size(404, 400);
            listView1.Location = new System.Drawing.Point(10, 10);
            this.Controls.Add(listView1);
            listView1.View = View.Details;
            listView1.GridLines = true;
            listView1.FullRowSelect = true;
            listView1.BeginUpdate();
            //Add column header
            
            //
            string filename = "CS6326Asg2.txt";
            if (!File.Exists(filename))
            {
                using (StreamWriter sw = File.CreateText(filename)) ;
            }
            //else {
            using (StreamReader sr = new StreamReader("CS6326Asg2.txt"))
            {
                try
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        String[] substrings = line.Split(' ');
                        string[] arr = new string[2];
                        ListViewItem itm;
                        //add items to ListView
                        arr[0] = substrings[0]+" "+substrings[1];
                        arr[1] = substrings[8];
                        itm = new ListViewItem(arr);
                        listView1.Items.Add(itm);
                        //lv.Items.Add(substrings[0]+" "+substrings[1],substrings[8]);
                    }
                }

                catch (Exception ex)
                {
                    Console.WriteLine("The file could not be read:");
                    Console.WriteLine(ex.Message);
                }
                sr.Close();
            }
            listView1.EndUpdate();
            return;
            //
        }
        
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }
        private void Delete_Click(object sender, EventArgs e)
        {
            int flag = 0;
            if (String.IsNullOrEmpty(textBox1.Text) || String.IsNullOrEmpty(textBox2.Text) || String.IsNullOrEmpty(textBox4.Text) || String.IsNullOrEmpty(textBox6.Text) || String.IsNullOrEmpty(textBox7.Text) || String.IsNullOrEmpty(textBox8.Text) || String.IsNullOrEmpty(textBox9.Text) || String.IsNullOrEmpty(textBox3.Text) || String.IsNullOrEmpty(textBox11.Text) || String.IsNullOrEmpty(textBox5.Text))
            {
                MessageBox.Show("No entry found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                flag = 1;
            }
            if (flag == 0) {
                string fn = textBox1.Text, ln = textBox2.Text, mi = textBox12.Text, ad1 = textBox11.Text, ad2 = textBox10.Text, city = textBox9.Text, state = textBox8.Text, zip = textBox7.Text;
                string ph = textBox6.Text, email = textBox5.Text, proof = textBox4.Text, date = textBox3.Text;
                string filename = "CS6326Asg2.txt";
                if (!File.Exists(filename))
                {
                    using (StreamWriter sw = File.CreateText(filename)) ;
                    //Console.WriteLine("AM I HERE?");
                }
                string tempFile = Path.GetTempFileName();

                using (var sr1 = new StreamReader("CS6326Asg2.txt"))
                using (var sw = new StreamWriter(tempFile))
                {
                    string line;

                    while ((line = sr1.ReadLine()) != null)
                    {
                        String[] substrings = line.Split(' ');
                        if (!(String.Equals(fn, substrings[0], StringComparison.Ordinal) && String.Equals(ln, substrings[1], StringComparison.Ordinal) && String.Equals(mi, substrings[2], StringComparison.Ordinal)))
                        {
                            sw.WriteLine(line);
                        }
                    }
                }

                File.Delete("CS6326Asg2.txt");
                File.Move(tempFile, "CS6326Asg2.txt");
                textBox1.Text = String.Empty; textBox2.Text = String.Empty; textBox3.Text = String.Empty; textBox4.Text = String.Empty; textBox5.Text = String.Empty;
                textBox6.Text = String.Empty; textBox7.Text = String.Empty; textBox8.Text = String.Empty; textBox9.Text = String.Empty; textBox10.Text = String.Empty;
                textBox11.Text = String.Empty; textBox12.Text = String.Empty;
                update();
            }
            String test = DateTime.Now.ToString("MM/dd/yyy");
            textBox3.Text = test;
        }

        private void Save_Click(object sender, EventArgs e)
        {
            int flag = 0, saveflag = 0;
            if (String.IsNullOrEmpty(textBox1.Text) || String.IsNullOrEmpty(textBox2.Text) || String.IsNullOrEmpty(textBox4.Text) || String.IsNullOrEmpty(textBox6.Text) || String.IsNullOrEmpty(textBox7.Text)|| String.IsNullOrEmpty(textBox8.Text) || String.IsNullOrEmpty(textBox9.Text) || String.IsNullOrEmpty(textBox3.Text) || String.IsNullOrEmpty(textBox11.Text) || String.IsNullOrEmpty(textBox5.Text))
            {
                MessageBox.Show("Complete all the fields marked as(*)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                flag = 1;
                saveflag = 1;
            }
            string fn = textBox1.Text,ln=textBox2.Text,mi=textBox12.Text,ad1=textBox11.Text,ad2=textBox10.Text,city=textBox9.Text,state=textBox8.Text,zip=textBox7.Text;
            string ph = textBox6.Text, email = textBox5.Text,proof=textBox4.Text,date=textBox3.Text;

            //FileStream fsOverwrite = new FileStream("C:\\test.txt", FileMode.Create);
            //StreamWriter swOverwrite = new StreamWriter(fsOverwrite);

            string filename = "CS6326Asg2.txt";
            if (!File.Exists(filename))
            {
                using (StreamWriter sw = File.CreateText(filename)) ;
            }
            //else {
            using (StreamReader sr = new StreamReader("CS6326Asg2.txt"))
            {
                try
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        String[] substrings = line.Split(' ');
                        //foreach (var substring in substrings)
                        //
                        //Console.WriteLine(substrings[0]);
                        if (String.Equals(fn, substrings[0], StringComparison.Ordinal) && String.Equals(ln, substrings[1], StringComparison.Ordinal) && String.Equals(mi, substrings[2], StringComparison.Ordinal))
                        {
                            MessageBox.Show("Record already exists. Please enter again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            flag = 1;
                            break;
                        }
                    }
                }

                catch (Exception ex)
                {
                    Console.WriteLine("The file could not be read:");
                    Console.WriteLine(ex.Message);
                }
                sr.Close();
            }
            //}
            if (flag == 0 && saveflag==0)
            {
                using (StreamWriter sw = new StreamWriter("CS6326Asg2.txt", true))
                {
                    try
                    {
                        sw.WriteLine(fn + " " + ln + " " + mi + " " + ad1 + " " + ad2 + " " + city + " " + state + " " + zip + " " + ph + " " + email + " " + proof + " " + date);
                        textBox1.Text = String.Empty; textBox2.Text = String.Empty; textBox3.Text = String.Empty; textBox4.Text = String.Empty; textBox5.Text = String.Empty;
                        textBox6.Text = String.Empty; textBox7.Text = String.Empty; textBox8.Text = String.Empty; textBox9.Text = String.Empty; textBox10.Text = String.Empty;
                        textBox11.Text = String.Empty; textBox12.Text = String.Empty;
                    }

                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.ToString());
                    }
                    sw.Close();
                }
            }
            update();         // IMPORTANT
            Modify.Enabled = true;
            if (tflag1 == 0 && tflag == 1)
            {
                ts = DateTime.Now.ToString("HH:mm:ss", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                textBox14.Text = ts;
                tflag1 = 1;
            }
        }
        private void Form1_DoubleClick(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lv_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listView1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            //restore.Enabled = false;
            textBox1.Text = String.Empty; textBox2.Text = String.Empty; textBox3.Text = String.Empty; textBox4.Text = String.Empty; textBox5.Text = String.Empty;
            textBox6.Text = String.Empty; textBox7.Text = String.Empty; textBox8.Text = String.Empty; textBox9.Text = String.Empty; textBox10.Text = String.Empty;
            textBox11.Text = String.Empty; textBox12.Text = String.Empty;
            String test = DateTime.Now.ToString("MM/dd/yyy");
            textBox3.Text = test;
            Modify.Enabled = false;
            Delete.Enabled = false;
            clear.Enabled = false;
            if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem item = listView1.SelectedItems[0];
                string i1=item.SubItems[0].Text,i2=item.SubItems[1].Text;

                //
                using (StreamReader sr = new StreamReader("CS6326Asg2.txt"))
                {
                    try
                    {
                        string line;
                        while ((line = sr.ReadLine()) != null)
                        {
                            String[] substrings = line.Split(' ');
                            if (String.Equals(i1, (substrings[0]+" "+substrings[1]), StringComparison.Ordinal) && String.Equals(i2, substrings[8], StringComparison.Ordinal))
                            {
                                textBox1.Text = substrings[0]; textBox2.Text = substrings[1]; textBox12.Text = substrings[2]; textBox11.Text = substrings[3]; textBox10.Text = substrings[4];
                                textBox9.Text = substrings[5]; textBox8.Text = substrings[6]; textBox7.Text = substrings[7]; textBox6.Text = substrings[8]; textBox5.Text = substrings[9];
                                textBox4.Text = substrings[10]; textBox3.Text = substrings[11];
                                break;
                            }
                        }
                    }

                    catch (Exception ex)
                    {
                        Console.WriteLine("The file could not be read:");
                        Console.WriteLine(ex.Message);
                    }
                    sr.Close();
                    Modify.Enabled = true;
                    Delete.Enabled = true;
                    clear.Enabled = true;
                }
                //

                //Console.WriteLine(i1 + " " + i2);
            }
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            restore.Enabled = false;
            Modify.Enabled = false;
            Delete.Enabled = false;
            clear.Enabled = false;
            listView1.Columns.Add("Full Name", 200);
            listView1.Columns.Add("Phone Number", 200);
            String test = DateTime.Now.ToString("MM/dd/yyy");
            textBox3.Text = test;
            update();
        }

        private void textBox3_Validating(object sender, CancelEventArgs e)
        {
            try
            {
                DateTime.Parse(textBox3.Text);
            }
            catch
            {
                textBox3.Text = DateTime.Today.ToShortDateString();
                MessageBox.Show("Invalid date. Set to today.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!(ch == 8 || ch == 46 || ch == 47 || Char.IsDigit(ch)))
                {
                e.Handled = true;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        // MODIFY
        private void Modify_Click(object sender, EventArgs e)
        {
            Delete.Enabled = false;
            restoreflag = 1;
            restore.Enabled = true;
            string fn1 = textBox1.Text, ln1 = textBox2.Text, mi1 = textBox12.Text, ad3 = textBox11.Text, ad4 = textBox10.Text, c1 = textBox9.Text, s1 = textBox8.Text, zip1 = textBox7.Text;
            string ph1 = textBox6.Text, e1 = textBox5.Text, proof1 = textBox4.Text, date1 = textBox3.Text;
            string fn = textBox1.Text, ln = textBox2.Text, mi = textBox12.Text, ad1 = textBox11.Text, ad2 = textBox10.Text, city = textBox9.Text, state = textBox8.Text, zip = textBox7.Text;
            string ph = textBox6.Text, email = textBox5.Text, proof = textBox4.Text, date = textBox3.Text;
            Modify.Enabled = false;
            //
            int flag = 0;
            if (String.IsNullOrEmpty(textBox1.Text) || String.IsNullOrEmpty(textBox2.Text) || String.IsNullOrEmpty(textBox4.Text) || String.IsNullOrEmpty(textBox6.Text) || String.IsNullOrEmpty(textBox7.Text) || String.IsNullOrEmpty(textBox8.Text) || String.IsNullOrEmpty(textBox9.Text) || String.IsNullOrEmpty(textBox3.Text) || String.IsNullOrEmpty(textBox11.Text) || String.IsNullOrEmpty(textBox5.Text))
            {
                MessageBox.Show("No entry found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                flag = 1;
                Modify.Enabled = true;
            }
            if (flag == 0)
            {
                //string fn = textBox1.Text, ln = textBox2.Text, mi = textBox12.Text, ad1 = textBox11.Text, ad2 = textBox10.Text, city = textBox9.Text, state = textBox8.Text, zip = textBox7.Text;
                //string ph = textBox6.Text, email = textBox5.Text, proof = textBox4.Text, date = textBox3.Text;
                string filename = "CS6326Asg2.txt";
                if (!File.Exists(filename))
                {
                    using (StreamWriter sw = File.CreateText(filename)) ;
                    //Console.WriteLine("AM I HERE?");
                }
                string tempFile = Path.GetTempFileName();

                using (var sr1 = new StreamReader("CS6326Asg2.txt"))
                using (var sw = new StreamWriter(tempFile))
                {
                    string line;

                    while ((line = sr1.ReadLine()) != null)
                    {
                        String[] substrings = line.Split(' ');
                        if (!(String.Equals(fn, substrings[0], StringComparison.Ordinal) && String.Equals(ln, substrings[1], StringComparison.Ordinal) && String.Equals(mi, substrings[2], StringComparison.Ordinal)))
                        {
                            sw.WriteLine(line);
                        }
                    }
                }

                File.Delete("CS6326Asg2.txt");
                File.Move(tempFile, "CS6326Asg2.txt");
            }
            update();
        }

        private void clear_Click(object sender, EventArgs e)
        {
            fn1 = textBox1.Text; ln1 = textBox2.Text; mi1 = textBox12.Text; ad3 = textBox11.Text; ad4 = textBox10.Text; c1 = textBox9.Text; s1 = textBox8.Text; zip1 = textBox7.Text; ph1 = textBox6.Text; e1 = textBox5.Text; proof1 = textBox4.Text; date1 = textBox3.Text;
            textBox1.Text = String.Empty; textBox2.Text = String.Empty; textBox3.Text = String.Empty; textBox4.Text = String.Empty; textBox5.Text = String.Empty;
            textBox6.Text = String.Empty; textBox7.Text = String.Empty; textBox8.Text = String.Empty; textBox9.Text = String.Empty; textBox10.Text = String.Empty;
            textBox11.Text = String.Empty; textBox12.Text = String.Empty;
            Modify.Enabled = false;
            Delete.Enabled = false;
            String test = DateTime.Now.ToString("MM/dd/yyy");
            textBox3.Text = test;
            restore.Enabled = true;
        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (tflag == 0)
            {
                ts = DateTime.Now.ToString("HH:mm:ss", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                textBox13.Text = ts;
                tflag = 1;
            }
            char ch = e.KeyChar;
            if (!Char.IsLetter(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsLetter(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void textBox12_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsLetter(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void textBox8_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!Char.IsLetter(ch) && ch != 8 && ch != 46)
            {
                e.Handled = true;
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            if (!(ch == 89 || ch == 121 || ch == 78 || ch == 110 || ch == 8 || ch == 46))
            {
                e.Handled = true;
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //restore.Enabled = true;
            textBox1.Text = fn1; textBox2.Text = ln1; textBox12.Text = mi1; textBox11.Text = ad3; textBox10.Text = ad4;
            textBox9.Text = c1; textBox8.Text = s1; textBox7.Text = zip1; textBox6.Text = ph1; textBox5.Text = e1;
            textBox4.Text = proof1; textBox3.Text = date1;
            restore.Enabled = false;
        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
